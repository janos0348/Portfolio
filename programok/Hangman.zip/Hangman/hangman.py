import random
def szovalasztas():
    with open("szavak.txt",'r') as f:
        szavak =  f.readlines()
        szo = random.choice(szavak)
        return szo
