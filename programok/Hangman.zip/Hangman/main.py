import hangman
tries = 6

szavam = hangman.szovalasztas()

def babu(tries):
    stages = ["""
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     / \\
                   -
                   """,
              """
                --------
                |      |
                |      O
                |     \\|/
                |      |
                |     /
                -
                """,
              """
                --------
                |      |
                |      O
                |     \\|/
                |      |
                |
                -
                """,
              """
                --------
                |      |
                |      O
                |     \\|
                |      |
                |
                -
                """,
              """
                --------
                |      |
                |      O
                |      |
                |      |
                |
                -
                """,
              """
                --------
                |      |
                |      O
                |
                |
                |
                -
                """,
              """
                --------
                |      |
                |      
                |
                |
                |
                -
                """
              ]
    return stages[tries]
hiddenword = ""
for i in szavam:
    hiddenword +=("_")
print(hiddenword)
while tries>0:
    tipp = input("\nTippelj: ")
    if tipp in hiddenword:
        for i in szavam:
            if j == tipp:
                hiddenword
            else:
                print("_", end="")
    else:
        print("")
    tries-=1