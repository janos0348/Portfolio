egy_cent = 0.1
for i in range(1,31):
    print(f"{i}. nap: {egy_cent}")
    egy_cent *= 2